n = input("n: ")
P = rantrans(n)
sum(P)
